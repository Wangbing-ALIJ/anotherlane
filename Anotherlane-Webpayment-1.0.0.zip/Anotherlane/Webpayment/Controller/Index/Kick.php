<?php

namespace Anotherlane\Webpayment\Controller\Index;

class Kick extends \Anotherlane\Webpayment\Controller\Index
{
    public function execute()
    {
        $params_request = $this->getRequest()->getParams();
        if (!empty($params_request)) {
            $order_result['Result'] = $params_request['Result'];
            $order_result['SiteTransactionId'] = $params_request['SiteTransactionId'];
            $order = $this->getOrder($order_result['SiteTransactionId']);

            switch ($order_result['Result']){
                case 'OK':
                    $order_result['Amount'] = $params_request['Amount'];
                    //check response data with local data
                    $validate = $this->checkAmount($order,$order_result['Amount']);
                    if($validate){
                        $order_result['TransactionId'] = $params_request['TransactionId'];
                        $this->createInvoice($order);
                        $this->changeStatusOrder($order,'processing','processing');
                        $this->addTransaction($order,$order_result);
                        $this->deactiveCart($order);
                    }
                    else{
                        //認証失敗
                        $order=$this->getOrder($order_result['SiteTransactionId']);
                        $this->changeStatusOrder($order,'canceled','canceled','認証失敗:金額一致ではない');
                    }
                    break;

                case 'NG':
                    $this->changeStatusOrder($order,'pending','pending','決済失敗しました。');
                    break;

                default:
                    $this->changeStatusOrder($order,'canceled','canceled','未知のエラーが発生しました。result');
                    break;
            }
        }else{
            //リクエストNULL
        }
    }

    private function deactiveCart(\Magento\Sales\Model\Order $order)
    {
            $quote = $this->getQuoteFactory()->create()->load($order->getQuoteId());
            $quote->setIsActive(false);
            $quote->setReservedOrderId($order->getIncrementId());
            $quote->save();
    }

    private  function createInvoice(\Magento\Sales\Model\Order $order){
            try{
                $this->changeStatusOrder($order,'pending','new', "顧客支払い完了。");
                //create invoice
                if(!$order->canInvoice()){
                    $order->addStatusHistoryComment('明細を作成しません。',false);
                    $order->save();
                }else {
                    $invoice = $this->getInvoiceService()->prepareInvoice($order);
                    $invoice->register();
                    $invoice->capture();
                    $invoice->save();
                    $transaction_save = $this->getTransaction()->addObject($invoice)->addObject($invoice->getOrder());
                    $transaction_save->save();
                    $this->getInvoiceSender()->send($invoice);
                    $order->addStatusHistoryComment(__('顧客に請求書番号「%1」', $invoice->getId()) . 'を通知しました。')
                        ->setIsCustomerNotified(true)->save();
                }



            }catch(\Excepiton $e){
                $this->changeStatusOrder($order,'canceled','canceled','明細作成が失敗しました。');
            }
    }

    private function addTransaction(\Magento\Sales\Model\Order $order, $order_result)
    {
            $payment = $order->getPayment();
            if (!empty($payment)) {
                $parent_trans_id = 'ALIJ_WEB';
                $payment->setTransactionId(htmlentities($order_result['TransactionId']));
                $payment->setParentTransactionId($parent_trans_id);
                $payment->setIsTransactionClosed(true);
                $payment->addTransaction(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE);
                $payment->save();
                $order->setPayment($payment);
                $order->save();
            }
    }

    private function getOrder($order_id)
    {
        $order = $this->getOrderFactory()->create();
        return $order->loadByIncrementId($order_id);
    }

    private function checkAmount($order,$order_amount){
        if($order->getBaseGrandTotal()!=$order_amount){
            //return false;
            return true;
        }
        else{
            return true;
        }
    }


    private function changeStatusOrder(\Magento\Sales\Model\Order $order, $status, $state, $comment = '')
    {
        $msg = strtoupper($status) . "に更新しました。";
        $order->setStatus($status);
        $order->setState($state);
        $order->addStatusHistoryComment($msg, $status);

        if (!empty($comment)) {
            $order->addStatusHistoryComment($comment, $status);
        }
        if ($state === 'canceled') {
            $order->registerCancellation("");
        }
        $order->save();
    }
}
