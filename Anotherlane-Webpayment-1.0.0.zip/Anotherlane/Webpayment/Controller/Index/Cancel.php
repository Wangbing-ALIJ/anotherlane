<?php
/**
 * Created by PhpStorm.
 * User: hoh
 * Date: 2017/10/24
 * Time: 19:33
 */
namespace Anotherlane\Webpayment\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Cancel extends \Anotherlane\Webpayment\Controller\Index
{
    public function execute()
    {
        $result_redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $result_redirect->setUrl($this->getStoreManager()->getStore()->getBaseUrl() . 'checkout/cart');
        return $result_redirect;
    }
}