<?php
/**
 * Created by PhpStorm.
 * User: hoh
 * Date: 2017/10/18
 * Time: 16:09
 */
namespace Anotherlane\Webpayment\Controller\Index;

class Index extends \Anotherlane\Webpayment\Controller\Index
{

    public function execute()
    {

        $order_id = $this->getCheckoutSession()->getLastRealOrderId();
        if (!empty($order_id)) {
            $order = $this->getOrderFactory()->create();
            $order->loadByIncrementId($order_id);

            if (true) {
                $quote = $this->getQuoteFactory()->create()->load($order->getQuoteId());
                $quote->setIsActive(true);
                $quote->setReservedOrderId(null);
                $quote->save();
                $this->getCheckoutSession()->setQuoteId($order->getQuoteId());
            }


            $products = '';
            $items = $order->getAllVisibleItems();
            foreach ($items as $itemId => $item) {
                $products .= $item->getName();
                $products .= ":" . $item->getQtyToInvoice();
                $products .= ",";
            }

            $siteId = $this->getHelper()->getconfigData('siteid');
            $sitePass = $this->getHelper()->getconfigData('sitepass');


            //$transaction_amount = number_format($order->getBaseGrandTotal(), 2, '', '');
            $transaction_amount = $order->getBaseGrandTotal();

            $form_another = '<form action="http://192.168.1.189:9000/service/credit" method="post" id="another" name="another">';
            $form_another .= '<input type="hidden" name="siteId" value="' . $siteId .'" />';
            $form_another .= '<input type="hidden" name="sitePass" value="'. $sitePass . '" />';
           // $form_another .= '<input type="hidden" name="itemId" value="' . $products . '" />';
            $form_another .= '<input type="hidden" name="amount" value="' . $transaction_amount . '" />';
            //$form_another .= '<input type="hidden" name="amount" value="200" />';
            $form_another .= '<input type="hidden" name="SiteTransactionId" value="' . $order_id . '" />';
            $form_another .= '</form>';
            $form_another .= '<h3> loading </h3>';
            $form_another .= '<script type="text/javascript">';
            $form_another .= 'document.another.submit();';
            $form_another .= '</script>';

            $this->addTransaction($order);

            $this->getResponse()->setBody($form_another);
            return;
        }
    }

    private function addTransaction(\Magento\Sales\Model\Order $order)
    {
        $payment = $order->getPayment();
        if (!empty($payment)) {
            $datetime = new \DateTime();
            $parent_trans_id = 'ALIJ_WEB';
            $payment->setTransactionId(htmlentities($parent_trans_id));
            $payment->setIsTransactionClosed(false);
            $payment->addTransaction(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_ORDER);

            $payment->setTransactionId(htmlentities('ALIJ_WEB' . $datetime->getTimestamp()));
            $payment->setParentTransactionId($parent_trans_id);
            $payment->setIsTransactionClosed(true);
            $payment->addTransaction(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_AUTH);

            $payment->save();
            $order->setPayment($payment);
            $order->save();
        }
    }
}
