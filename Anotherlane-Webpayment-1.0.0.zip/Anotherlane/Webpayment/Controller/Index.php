<?php
/**
 * Created by PhpStorm.
 * User: hoh
 * Date: 2017/10/18
 * Time: 16:10
 */
namespace Anotherlane\Webpayment\Controller;

use Magento\Store\Model\StoreManager;



abstract class Index extends \Magento\Framework\App\Action\Action{

    private $order_factory;

    private $store_manager;

    private $customer_session;

    private $checkout_session;

    private $quote_factory;

    private $transaction;

    private $invoice_service;

    private $invoice_sender;

    private $helper;

    public function setCustomerSession(\Magento\Customer\Model\Session $customer_session)
    {
        $this->customer_session = $customer_session;
    }

    public function setOrderFactory(\Magento\Sales\Model\OrderFactory $order_factory)
    {
        $this->order_factory = $order_factory;
    }

    public function getOrderFactory()
    {
        return $this->order_factory;
    }

    public function setCheckoutSession(\Magento\Checkout\Model\Session $checkout_session)
    {
        $this->checkout_session = $checkout_session;
    }

    public function getCheckoutSession()
    {
        return $this->checkout_session;
    }

    public function setStoreManager(\Magento\Store\Model\StoreManagerInterface $store_manager)
    {
        $this->store_manager = $store_manager;
    }

    public function getStoreManager()
    {
        return $this->store_manager;
    }

    public function getQuoteFactory()
    {
        return $this->quote_factory;
    }

    public function setQuoteFactory(\Magento\Quote\Model\QuoteFactory $quote_factory)
    {
        $this->quote_factory = $quote_factory;
    }

    public function getInvoiceService()
    {
        return $this->invoice_service;
    }

    public function setInvoiceService(\Magento\Sales\Model\Service\InvoiceService $invoice_service)
    {
        $this->invoice_service = $invoice_service;
    }

    public function getTransaction()
    {
        return $this->transaction;
    }

    public function setTransaction(\Magento\Framework\DB\Transaction $transaction)
    {
        $this->transaction = $transaction;
    }

    public function getInvoiceSender()
    {
        return $this->invoice_sender;
    }

    public function setInvoiceSender(\Magento\Sales\Model\Order\Email\Sender\InvoiceSender $invoice_sender)
    {
        $this->invoice_sender = $invoice_sender;
    }

    public function getHelper()
    {
        return $this->helper;
    }

    public function setHelper(\Anotherlane\Webpayment\Model\ConfigData\Data $helper)
    {
        $this->helper = $helper;
    }


    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Sales\Model\Order\Email\Sender\InvoiceSender $invoice_sender,
        \Magento\Sales\Model\Service\InvoiceService $invoice_service,
        \Magento\Framework\DB\Transaction $transaction,
        \Magento\Sales\Model\OrderFactory $order_factory,
        \Magento\Framework\App\ObjectManagerFactory $object_factory,
        \Magento\Store\Model\StoreManagerInterface $store_manager,
        \Magento\Quote\Model\QuoteFactory $quote_factory
    ){
        parent::__construct($context);
        $this->setStoreManager($store_manager);
        $this->setOrderFactory($order_factory);
        $params[StoreManager::PARAM_RUN_CODE] = 'admin';
        $params[StoreManager::PARAM_RUN_TYPE] = 'store';
        $object_manager = $object_factory->create($params);
        $this->setCheckoutSession($object_manager->create(\Magento\Checkout\Model\Session::class));
        $this->setCustomerSession($object_manager->create(\Magento\Customer\Model\Session::class));
        $this->setQuoteFactory($quote_factory);
        $this->setInvoiceService($invoice_service);
        $this->setTransaction($transaction);
        $this->setInvoiceSender($invoice_sender);
        $this->setHelper($object_manager->create('Anotherlane\Webpayment\Model\ConfigData\Data'));
    }
}