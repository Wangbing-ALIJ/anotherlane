<?php
/**
 * Created by PhpStorm.
 * User: hoh
 * Date: 2017/10/20
 * Time: 18:41
 */
namespace Anotherlane\Webpayment\Model\ConfigData;

class Data extends \Magento\Framework\App\Helper\AbstractHelper{

    public function getConfigData(
        $field,
        $storeId = null
    ) {

        $path = 'payment/webpayment/' . $field;
        return $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }
}